<!DOCTYPE html>
<html lang="en">
<head>
    <title>digiTX Computer Technology</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&amp;subset=latin-ext" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
   <!-- SmartMenus core CSS (required) -->
    <link href="./MenuCSSJS/sm-core-css.css" rel="stylesheet" type="text/css" />
    <!-- "sm-blue" menu theme (optional, you can use your own CSS, too) -->
    <link href="./MenuCSSJS/sm-blue.css" rel="stylesheet" type="text/css" />
    <link href="top_courses_Css/style.css" rel="stylesheet">
 	<link href="top_courses_Css/bootstrap.min.css" rel="stylesheet">
	<style>
	input[type=text], select {
	  width: 100%;
	  padding: 12px 20px;
	  margin: 8px 0;
	  display: inline-block;
	  border: 1px solid #ccc;
	  border-radius: 4px;
	  box-sizing: border-box;
	}
</style>

    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script>
	function onlyNumberKey(evt) {

		// Only ASCII character in that range allowed
		var ASCIICode = (evt.which) ? evt.which : evt.keyCode
		if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
			return false;
		return true;
	}
</script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-F5RSS36NBS"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-F5RSS36NBS');
</script>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body id="top">
<!-- link rel="stylesheet" href="main.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script>
<script src="main.js"></script>
	<div id="boxes">
	  <div style="top: 199.5px; left: 551.5px; display: none;" id="dialog" class="window">
	    <div id="lorem">
	      <p><img src="summer_course.jpg" height=400 width=440></p>
	    </div>
	    <div id="popupfoot"> <a href="#" class="close agree">OK</a>  </div>
	  </div>
	  <div style="width: 478px; font-size: 32pt; color:white; height: 650px; display: none; opacity: 0.8;" id="mask"></div>
	</div -->
    <header class="site-header">
        <div class="top">
            <div class="container">
				<div class="row">
					<div class="col-sm-6">
						<p><a href="index.html"><img src="img/logo.jpg" height=50% width=40%></a><font color=black size=2>A Professional Training Institute.</font></p><br>
					</div>
					<div class="col-sm-6">
							<div class="right-div">
					            <a href="#" class="btn btn-success pull-right">ISO 9001-2015 Certified</a>
					            <a href="#" class="btn btn-danger pull-right">Registered Under Govt. of Odisha.</a>
 								<a href="#" class="btn btn-primary pull-right">Phone: 9937743083, Email: info@digitx.in &nbsp;&nbsp;</a>
            				</div>

						<!-- ul class="list-inline pull-right">
							<li>

								 <a href="sc_register.php"  class="btn btn-primary pull-right"> Register</a>&nbsp;&nbsp;
								 <a href="NOTICE.html"  class="btn btn-primary pull-right">NOTICE</a> &nbsp;&nbsp;
							</li>
						</ul -->
					</div>
				</div>
            </div>
        </div>
	       <nav id="main-nav">
	         <!-- Sample menu definition -->
	         <ul id="main-menu" class="sm sm-blue">
	           <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
	           <li><a href="index.html">HOME</a></li>
	           <li><a href="AboutUs.html">ABOUT US</a></li>
	           <li><a href="#">ACADEMIC</a>
	             <ul>
	               <li><a href="RegistrationProcess.html">Registration Process</a></li>
	               <li><a href="TrainingMethodology.html">Training Methodology</a></li>
	               <li><a href="Certification.html">Certification</a></li>
	               <!-- li><a href="#">The company</a>
	                 <ul>
	                   <li><a href="#">About Vadikom</a></li>
	                   <li><a href="#">Projects</a></li>
	                   <li><a href="#">Services</a></li>
	                   <li><a href="#">Privacy policy</a></li>
	                 </ul>
	               </li -->
	             </ul>
	           </li>
			   <li><a href="#">COURSES</a>
				 <ul>
				   <li><a href="IT_ITESCourses.html">IT/ITES Courses</a></li>
				   <li><a href="SchoolStudentsCourse.html">Courses for School going Students</a></li>
				   <li><a href="ProfessionalCourses.html">Professional Courses</a></li>
				   <li><a href="Seminars_Workshops.html">Seminars and Workshops</a></li>
				   <li><a href="Tool_Technologies.html">Tools/Technologies</a></li>
				   <li><a href="SoftwareDevelopment.html">Software Project Management</a></li>
				 </ul>
	           </li>
	           <li><a href="Check_Certificate.php">CHECK CERTIFICATE</a></li>
	           <li><a href="sc_register.php">REGISTER</a></li>
	           <li><a href="NOTICE.html">NOTICE</a></li>
	           <li><a href="Contact.php">CONTACT US</a></li>
	         </ul>
    </nav>
    </header>
    <main class="site-main">
        <section class="home-area">
            <div class="home_content">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12"><h2 class="sub_title"><font color=red size=6>Admission Open for the year 2022-2023. Join Soon!! Call us @99377 43083</font></h2></div>
                        <div class="col-sm-9 home_bottom">
                            <div class="clearfix"> </div>
                            <div class="row">
                                <div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="6000" id="myCarousel">
                                    <div class="carousel-inner">
                                    <p>
                                    	 <form method="POST" id="customForm" action="sc_register.php">


											<table class="table table-bordered">
											<tr>
												<td colspan=3><h2>Register for a Course/Training </h2></td>
											</tr>
													<tr>
															<td colspan=3></td>
														 </tr>
														 <tr>
															<td>FullName:</td>
															<td colspan=2><input id="FullName" name="FullName" size=45 type="text" placeholder="FullName is required" /></td>
														</tr>
														<tr>
															<td>Phone:</td>
															<td colspan=2><input id="FullName" name="Phone" size=35 type="text" maxlength=10 onkeypress="return onlyNumberKey(event)" placeholder="A valid Phone Number is required." /></td>
														</tr>
														<tr>
															<td>Email:</td>
															<td colspan=2><input id="FullName" name="Email" size=35 type="text" placeholder="A valid eMail Id is required." /></td>
														</tr>
														<tr>
															<td nowrap>Current / Last Education:</td>
															<td colspan=2>
																<select id="Education" name="Education" >
																	<option value="">Please Select One &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
																	<option value="IA">+2 ARTS</option>
																	<option value="ICom">+2 Commerce</option>
																	<option value="ISc">+2 Science</option>
																	<option value="BA">+3 ARTS</option>
																	<option value="BCOM">+3 Commerce</option>
																	<option value="BSC">+3 Science</option>
																	<option value="BCA">BCA</option>
																	<option value="BBA">BBA</option>
																	<option value="MCA">MCA</option>
																	<option value="MSc">MSc.</option>
																	<option value="MSc">MTech</option>
																	<option value="Others">Others</option>
																</select>
															</td>
														</tr>
														<tr>
															<td nowrap>Course Interested for: </td>
															<td colspan=2>
																<select id="Course" name="Course" >
																	<option value="">Please Select One</option>
																	<option value="BCC">Basic Computer Course</option>
																	<option value="DCA">Diploma in Computer Application (DCA)</option>
																	<option value="PGDCA">PGDCA</option>
																	<option value="Tally">Tally-ERP-9</option>
																	<option value="HWL">Hardware/Linux</option>
																	<option value="HWL">Computer System Architecture</option>
																	<option value="RDBMS">RDBMS</option>
																	<option value="SQLPLSQL">SQL / PLSQL</option>
																	<option value="DMDWH">Data Mining / Data Warehousing</option>
																	<option value="PhpMySql">PHP/MySql</option>
																	<option value="DotNet">MS .Net</option>
																	<option value="CC++C#">C/C++/C#</option>
																	<option value="Java">Java</option>
																	<option value="Oracle">Oracle</option>
																	<option value="RDBMS">RDBMS</option>
																	<option value="RDBMS">Data Structure</option>
																	<option value="SoftDev">Software Development</option>
																	<option value="Designing">Web Designing</option>
																	<option value="HTML_DHTML_JQuery_Bootstrap">HTML/DHTML/JQuery/Bootstrap</option>
																	<option value="SEGDPI">Spoken English / GDPI</option>
																	<option value="Others">Others</option>
																</select>
															</td>
														</tr>
														<tr >
															<td colspan=3 align=center>

<img src="d1117_CaptchaSecurityImages.php?width=100&height=40&characters=5" />
		<label for="security_code">Security Code: </label><input id="security_code" name="security_code" type="text" size=40 placeholder="Type the SequrityCode Shown in the Image" />

															</td>
														</tr>
														<tr >
															<td colspan=3 align=center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input id="send" class="btn btn-primary btn-sm" type="submit" name="submit" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Register&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" /></td>
														</tr>
												</table>
												</td>
											 </tr>
											</table>
										</form>
									</p>
										<p>
												<p>&nbsp;</p>
												<h2 class="media-heading"><a href="#">Students Enrolled...</a></h2>
													 <div class="row">
													  <div class="col-md-4">
														<div class="stat">
														  <span data-counter-up>85</span>
														  <small> 2018-2019 Session</small>
														</div>
													  </div>
													  <div class="col-md-4">
														<div class="stat">
														  <span data-counter-up>113</span>
														  <small>2019-2020 Session</small>
														</div>
													  </div>
													  <div class="col-md-4">
														<div class="stat">
														  <span data-counter-up>42</span>
														  <small>2020-2021 Session</small>
														</div>
													  </div>
													</div>
									   </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <h2 class="sub_title w10">Courses we offer...</h2>
                            <div class="clearfix"></div>
                            <div class="login-form-1"><table  class="table table-bordered">
<tr>
 			<tr>
		<td nowrap align=center><font size=2>Diploma in Computer Application<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Post Graduate Diploma in Computer Application<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Hardware<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Computer System Architecture<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Relational Database Management System<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Structured Query Language<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Data Mining / Data Warehousing<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Digital Marketing<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Software Development<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>PHP/MySql<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Java<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Oracle<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Web Designing<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>HTML/DHTML/JQuery/Bootstrap<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>MS .Net<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>C<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>C++<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>C#<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Spoken English<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Group Discussion and Personal Interview<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Advanced Diploma in Computer Application<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Tally DFA T9<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Java Oracle<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Basic of MS Office (WordExcelPPT)<br></font></td>
		</tr>
 			<tr>
		<td nowrap align=center><font size=2>Basic Computer Course<br></font></td>
		</tr>
 	</table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
 </main>
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12 fbox">
                    <h4>digiTX Computer Technology</h4>
						<p class="text">Join us to Enrich your</p>
						<ul class="list-inline">
							<li><a href="IT_ITESCourses.html">> Programming Ability</a></li>
							<li><a href="IT_ITESCourses.html">> Soft Skills</a></li>
							<li><a href="IT_ITESCourses.html">> Designing Skills</a></li>
							<li><a href="ProfessionalCourses.html">> Career in IT Field.</a></li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 fbox">
						<h4>SERVICES WE PROVIDE</h4>
						<ul class="big">
							<li><a href="TrainingMethodology.html">- Training</a></li>
							<li><a href="Certification.html">- Certification</a></li>
							<li><a href="SoftwareDevelopment.html">- Developement</a></li>
							<li><a href="SoftwareDevelopment.html">- Design</a></li>
							<li><a href="IT_ITESCourses.html">- Soft Skills</a></li>
							<li><a href="IT_ITESCourses.html">- GDPI</a></li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 fbox">
						<h4>TOOLS and TECHNOLOGY</h4>
						<ul class="big">
							<li><a href="Tool_Technologies.html">- PHP, MySql</a></li>
							<li><a href="Tool_Technologies.html">- Java-Oracle</a></li>
							<li><a href="Tool_Technologies.html">- Python</a></li>
							<li><a href="Tool_Technologies.html">- C, C++</a></li>
							<li><a href="Tool_Technologies.html">- Jquery, JS</a></li>
							<li><a href="Tool_Technologies.html">- HTML, JQuery</a></li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 fbox">
						<h4>Address:</h4>
						<p class="big"><a href="Contact.php">At. GM University Chhak, A. N. Guha Lane, Odisha  Sambalpur. 768004.</a></p>
						<p><a href="Contact.php">Phone: 99377 43083, 98530 58595</a></p>
					</div>
				</div>
			</div>
		<div id="copyright">
            <div class="container">
				<div class="row">
					<div class="col-md-4">
						<p class="pull-left">&copy; 2017 digiTX Computer Technology</p>
					</div>
					<div class="col-md-8">
						<ul class="list-inline navbar-right">
							<li><a href="index.html">HOME</a></li>
							<li><a href="Tool_Technologies.html">Technology</a></li>
							<li><a href="ProfessionalCourses.html">Training</a></li>
							<li><a href="IT_ITESCourses.html">Courses</a></li>
							<li><a href="Contact.php">Contact</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
        $('.carousel[data-type="multi"] .item').each(function(){
          var next = $(this).next();
          if (!next.length) {
            next = $(this).siblings(':first');
          }
          next.children(':first-child').clone().appendTo($(this));

          for (var i=0;i<4;i++) {
            next=next.next();
            if (!next.length) {
                next = $(this).siblings(':first');
            }

            next.children(':first-child').clone().appendTo($(this));
          }
        });
    </script>
    <!-- jQuery -->
    <script type="text/javascript" src="./MenuCSSJS/jquery.js"></script>

    <!-- SmartMenus jQuery plugin -->
    <script type="text/javascript" src="./MenuCSSJS/jquery.smartmenus.js"></script>

    <!-- SmartMenus jQuery Keyboard Addon -->
    <script type="text/javascript" src="./MenuCSSJS/jquery.smartmenus.keyboard.js"></script>

    <!-- SmartMenus jQuery init -->
    <script type="text/javascript">
    	$(function() {
    		$('#main-menu').smartmenus({
    			subMenusSubOffsetX: 1,
    			subMenusSubOffsetY: -8
    		});
    		$('#main-menu').smartmenus('keyboardSetHotkey', '123', 'shiftKey');
    	});
    </script>
</body>
</html>