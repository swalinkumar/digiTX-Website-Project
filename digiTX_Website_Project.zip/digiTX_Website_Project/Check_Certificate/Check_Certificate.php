<!DOCTYPE html>
<html lang="en">
<head>
    <title>digiTX Computer Technology</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&amp;subset=latin-ext" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
   <!-- SmartMenus core CSS (required) -->
    <link href="./MenuCSSJS/sm-core-css.css" rel="stylesheet" type="text/css" />
    <!-- "sm-blue" menu theme (optional, you can use your own CSS, too) -->
    <link href="./MenuCSSJS/sm-blue.css" rel="stylesheet" type="text/css" />
    <link href="top_courses_Css/style.css" rel="stylesheet">
 	<link href="top_courses_Css/bootstrap.min.css" rel="stylesheet">
	<style>
	input[type=text], select {
	  width: 100%;
	  padding: 12px 20px;
	  margin: 8px 0;
	  display: inline-block;
	  border: 1px solid #ccc;
	  border-radius: 4px;
	  box-sizing: border-box;
	}
</style>
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-F5RSS36NBS"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-F5RSS36NBS');
</script>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body id="top">
<!-- link rel="stylesheet" href="main.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script>
<script src="main.js"></script>
	<div id="boxes">
	  <div style="top: 199.5px; left: 551.5px; display: none;" id="dialog" class="window">
	    <div id="lorem">
	      <p><img src="summer_course.jpg" height=400 width=440></p>
	    </div>
	    <div id="popupfoot"> <a href="#" class="close agree">OK</a>  </div>
	  </div>
	  <div style="width: 478px; font-size: 32pt; color:white; height: 650px; display: none; opacity: 0.8;" id="mask"></div>
	</div -->
    <header class="site-header">
        <div class="top">
            <div class="container">
				<div class="row">
					<div class="col-sm-6">
						<p><a href="index.html"><img src="img/logo.jpg" height=50% width=40%></a><font color=black size=2>A Professional Training Institute.</font></p><br>
					</div>
					<div class="col-sm-6">
							<div class="right-div">
					            <a href="#" class="btn btn-success pull-right">ISO 9001-2015 Certified</a>
					            <a href="#" class="btn btn-danger pull-right">Registered Under Govt. of Odisha.</a>
 								<a href="#" class="btn btn-primary pull-right">Phone: 9937743083, Email: info@digitx.in &nbsp;&nbsp;</a>
            				</div>

						<!-- ul class="list-inline pull-right">
							<li>

								 <a href="sc_register.php"  class="btn btn-primary pull-right"> Register</a>&nbsp;&nbsp;
								 <a href="NOTICE.html"  class="btn btn-primary pull-right">NOTICE</a> &nbsp;&nbsp;
							</li>
						</ul -->
					</div>
				</div>
            </div>
        </div>
	       <nav id="main-nav">
	         <!-- Sample menu definition -->
	         <ul id="main-menu" class="sm sm-blue">
	           <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
	           <li><a href="index.html">HOME</a></li>
	           <li><a href="AboutUs.html">ABOUT US</a></li>
	           <li><a href="#">ACADEMIC</a>
	             <ul>
	               <li><a href="RegistrationProcess.html">Registration Process</a></li>
	               <li><a href="TrainingMethodology.html">Training Methodology</a></li>
	               <li><a href="Certification.html">Certification</a></li>
	               <!-- li><a href="#">The company</a>
	                 <ul>
	                   <li><a href="#">About Vadikom</a></li>
	                   <li><a href="#">Projects</a></li>
	                   <li><a href="#">Services</a></li>
	                   <li><a href="#">Privacy policy</a></li>
	                 </ul>
	               </li -->
	             </ul>
	           </li>
			   <li><a href="#">COURSES</a>
				 <ul>
				   <li><a href="IT_ITESCourses.html">IT/ITES Courses</a></li>
				   <li><a href="SchoolStudentsCourse.html">Courses for School going Students</a></li>
				   <li><a href="ProfessionalCourses.html">Professional Courses</a></li>
				   <li><a href="Seminars_Workshops.html">Seminars and Workshops</a></li>
				   <li><a href="Tool_Technologies.html">Tools/Technologies</a></li>
				   <li><a href="SoftwareDevelopment.html">Software Project Management</a></li>
				 </ul>
	           </li>
	           <li><a href="Check_Certificate.php">CHECK CERTIFICATE</a></li>
	           <li><a href="sc_register.php">REGISTER</a></li>
	           <li><a href="NOTICE.html">NOTICE</a></li>
	           <li><a href="Contact.php">CONTACT US</a></li>
	         </ul>
    </nav>
    </header>
    <main class="site-main">
        <section class="home-area">
            <div class="home_content">
                <div class="container">
                    <div class="row">
                    <div class="col-sm-9 home_bottom">
                            <h2 class="sub_title">Check a Certificate Issued: or write to us for a verification. info@digiTX.in</h2>
                            <div class="clearfix">Please provide the Certficate Number and Roll Number of the student to get its details..</div>
                            <div class="row">
                                <div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="6000" id="myCarousel">
                                    <div class="carousel-inner">
                                    <p>
                                    	<form method="POST" id="customForm" action="">
											<div class="left_side">
												<label for="Certificate"><span class="small"><b>Certificate No:</b></span></label>
												<input id="Certificate" name="Certificate" size=30 type="text" />
												<label for="Certificate"><span class="small"><b>Student Roll No:</b></span></label>
												<input id="RollNo" name="RollNo" size=30 type="text" />
												<input id="send" class="btn btn-primary btn-sm" type="submit" name="submit" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Show Details&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" />
											</div>
										</form>
									</p>
										<p>
																								   										<p>

									   </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <h2 class="sub_title w10">Certificate Sample:</h2>
                            <div class="clearfix"></div>
                            <div class="login-form-1">
                                  <img src="./img/cert.jpg">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		    </main>
		    <footer class="site-footer">
		        <div class="container">
		            <div class="row">
		                <div class="col-md-3 col-sm-6 col-xs-12 fbox">
		                    <h4>digiTX Computer Technology</h4>
								<p class="text">Join us to Enrich your</p>
								<ul class="list-inline">
									<li><a href="IT_ITESCourses.html">> Programming Ability</a></li>
									<li><a href="IT_ITESCourses.html">> Soft Skills</a></li>
									<li><a href="IT_ITESCourses.html">> Designing Skills</a></li>
									<li><a href="ProfessionalCourses.html">> Career in IT Field.</a></li>
								</ul>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12 fbox">
								<h4>SERVICES WE PROVIDE</h4>
								<ul class="big">
									<li><a href="TrainingMethodology.html">- Training</a></li>
									<li><a href="Certification.html">- Certification</a></li>
									<li><a href="SoftwareDevelopment.html">- Developement</a></li>
									<li><a href="SoftwareDevelopment.html">- Design</a></li>
									<li><a href="IT_ITESCourses.html">- Soft Skills</a></li>
									<li><a href="IT_ITESCourses.html">- GDPI</a></li>
								</ul>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12 fbox">
								<h4>TOOLS and TECHNOLOGY</h4>
								<ul class="big">
									<li><a href="Tool_Technologies.html">- PHP, MySql</a></li>
									<li><a href="Tool_Technologies.html">- Java-Oracle</a></li>
									<li><a href="Tool_Technologies.html">- Python</a></li>
									<li><a href="Tool_Technologies.html">- C, C++</a></li>
									<li><a href="Tool_Technologies.html">- Jquery, JS</a></li>
									<li><a href="Tool_Technologies.html">- HTML, JQuery</a></li>
								</ul>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12 fbox">
								<h4>Address:</h4>
								<p class="big"><a href="Contact.php">At. GM University Chhak, A. N. Guha Lane, Odisha  Sambalpur. 768004.</a></p>
								<p><a href="Contact.php">Phone: 99377 43083, 98530 58595</a></p>
							</div>
						</div>
					</div>
				<div id="copyright">
		            <div class="container">
						<div class="row">
							<div class="col-md-4">
								<p class="pull-left">&copy; 2017 digiTX Computer Technology</p>
							</div>
							<div class="col-md-8">
								<ul class="list-inline navbar-right">
									<li><a href="index.html">HOME</a></li>
									<li><a href="Tool_Technologies.html">Technology</a></li>
									<li><a href="ProfessionalCourses.html">Training</a></li>
									<li><a href="IT_ITESCourses.html">Courses</a></li>
									<li><a href="Contact.php">Contact</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
		    </footer>

		    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		    <script src="js/bootstrap.min.js"></script>
		    <script type="text/javascript">
		        $('.carousel[data-type="multi"] .item').each(function(){
		          var next = $(this).next();
		          if (!next.length) {
		            next = $(this).siblings(':first');
		          }
		          next.children(':first-child').clone().appendTo($(this));

		          for (var i=0;i<4;i++) {
		            next=next.next();
		            if (!next.length) {
		                next = $(this).siblings(':first');
		            }

		            next.children(':first-child').clone().appendTo($(this));
		          }
		        });
		    </script>
		    <!-- jQuery -->
		    <script type="text/javascript" src="./MenuCSSJS/jquery.js"></script>

		    <!-- SmartMenus jQuery plugin -->
		    <script type="text/javascript" src="./MenuCSSJS/jquery.smartmenus.js"></script>

		    <!-- SmartMenus jQuery Keyboard Addon -->
		    <script type="text/javascript" src="./MenuCSSJS/jquery.smartmenus.keyboard.js"></script>

		    <!-- SmartMenus jQuery init -->
		    <script type="text/javascript">
		    	$(function() {
		    		$('#main-menu').smartmenus({
		    			subMenusSubOffsetX: 1,
		    			subMenusSubOffsetY: -8
		    		});
		    		$('#main-menu').smartmenus('keyboardSetHotkey', '123', 'shiftKey');
		    	});
		    </script>
		</body>
</html>